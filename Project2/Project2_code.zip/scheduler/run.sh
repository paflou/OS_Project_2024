 ./scheduler FCFS homogeneous.txt
 ./scheduler RR 1000 homogeneous.txt

 ./scheduler FCFS reverse.txt
 ./scheduler RR 1000 reverse.txt

 ./scheduler_io FCFS mixed.txt
 ./scheduler_io RR 1000 mixed.txt

